﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace userss.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpGet]
        public List<users> GetUserList()
        {
            List<users> Users = new List<users>();
            users u = new();
            u.id = 1;
            u.name = "Admin";
            u.phone = "+994996669966";
            Users.Add(u);
            return Users;
                
        }
    }

    public class users
    {
        public int id { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
    }
}
